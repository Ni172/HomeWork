import configparser
import os # used to Loading file relative from project root


class TestData:
    def __init__(self):
        self.config = configparser.ConfigParser()

    def get_data(self, section, Key):
        """
        This function will return data from our ini file testdata.ini.ini (our config file).
        change a string into lowercase - note that in the ini file it's lowercase
        :param section: the heather for example in our file: DEFAULT or SNMP, section - is not case sensitive
        :param Key: the value under the ask section(called Keys/option) Key - is not case sensitive
        :return: return data from our ini file
        """
        # change a string into lowercase - note that in the ini file it's lowercase
        section = section.lower()
        # Loading file relative from project root
        dir_root = os.path.abspath(os.path.dirname(__file__))
        test_data_path = os.path.join(dir_root, 'testdata.ini')
        try:
            self.config.read(test_data_path)
            return self.config[section][Key]

        except IOError:
            print('failed to open the ini file')


    def set_data(self, section, Key, value):
        """
        for example:
        config.set_data('default', 'browser', 'chrome' )
        give as:
                  [default]
                  browser = chrome
        :param section: the heather for example in our file: DEFAULT or SNMP, section - is not case sensitive
        :param Key: the value under the ask section(called Keys/option) Key - is not case sensitive
        :param value: the needed data to save.
        :return: None
        """
        section = section.lower()
        dir_root = os.path.abspath(os.path.dirname(__file__))
        test_data_path = os.path.join(dir_root, 'testdata.ini')
        try:
            self.config.read(test_data_path)
            with open(test_data_path, 'w') as configfile:
                self.config[section][Key] = str(value)
                self.config.write(configfile)
                configfile.flush()
                configfile.close()
        except IOError:
            print('failed to write the ini file')

